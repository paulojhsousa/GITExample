# IOT-DB410c-Course-2
In this repository, you will find the code for Internet of Things Course 2: Setting Up Your DragonBoard™ Development Platform on coursera.org
